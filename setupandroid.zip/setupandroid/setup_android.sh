#!/bin/bash

set -e

echo "======================================"
echo "      AOSP Setup Script (Linux)       "
echo "======================================"

# 1. Create workspace
mkdir -p ~/android
cd ~/android

echo "[1/5] Installing AOSP dependencies..."

sudo apt update

sudo apt install -y \
git curl wget repo gnupg flex bison build-essential zip unzip \
zlib1g-dev libc6-dev-i386 lib32ncurses5-dev x11proto-core-dev \
libx11-dev libgl1-mesa-dev libxml2-utils xsltproc bc ccache \
python3 python3-pip openjdk-17-jdk

echo "[2/5] Setting Git identity..."

git config --global user.name "AOSP Builder"
git config --global user.email "aosp@local"

echo "[3/5] Initializing AOSP repo..."

# IMPORTANT: change this to a valid AOSP branch
# Examples: android-14.0.0_rXX, android-13.0.0_rXX, etc.

BRANCH="android-14.0.0_r21"

repo init -u https://android.googlesource.com/platform/manifest -b $BRANCH

echo "[4/5] Syncing source (this will take time)..."

repo sync -c -j$(nproc --all)

echo "[5/5] Done!"
echo "AOSP source is ready in ~/android"
